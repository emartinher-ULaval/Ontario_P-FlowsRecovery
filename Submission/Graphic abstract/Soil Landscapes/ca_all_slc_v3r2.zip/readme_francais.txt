ENSEMBLE DE DONN�ES : P�DO-PAYSAGES DU CANADA
VERSION: 3.2
DATE: 2011.03.08
�CHELLE: 1:1 000 000
PROJECTION:
  G�ographique  unit�s == degr�s d�cimaux  r�f�rence g�od�sique = NAD83  diff�rence de longitude fictive = 0.0  ordonn�es fictive = 0.0  latitude d'origine = 0 0 0 
CITATION:
  Le groupe de travail sur les P�do-paysages du Canada, 2011.  P�do-paysage
  du Canada version 3.2.  Agriculture et Agroalimentaire Canada.
DROIT D'AUTEUR:
  Toute personne peut utiliser ces donn�es gratuitement, � condition de pr�ciser
  qu'elles proviennent d'Agriculture et Agroalimentaire Canada. AAC conserve les 
  droits exclusifs, le titre et la propri�t� de ces donn�es.
  Il est permis de copier et de diffuser ces donn�es en totalit�
  ou en partie, pourvu que le contenu de ce dossier fasse partie de 
  la diffusion. Il se peut qu'AAC ne puisse pas r�pondre aux demandes 
  d'information sur des donn�es obtenues d'une tierce partie.
D�N�GATION:
  Malgr� tous les efforts qui ont �t� faits afin de fournir l�exactitude, la continuit�
  et la fiabilit� du contenu, Agriculture et Agroalimentaire Canada n�assume aucune
  responsabilit� directe ou indirecte de ces donn�es. 

AGENCE:
  Service d'information sur le sol du Canada (CanSIS)  Agriculture et Agroalimentaire Canada (AAC)
  �difice K.W. Neatby, bureau 1135  Ottawa (Ontario)  K1A 0C6
  Courriel : infocansis@agr.gc.ca

DOCUMENTATION: 
  http://sis.agr.gc.ca/siscan/nsdb/slc/v3.2/intro.html